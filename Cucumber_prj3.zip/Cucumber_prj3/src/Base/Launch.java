package Base;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Launch {
	WebDriver dr;
	public void Launch(WebDriver dr) {
		this.dr=dr;
		
	}
public void launchBrowser() {
	 System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
     dr = new ChromeDriver();
	 dr.get("http://demowebshop.tricentis.com/");
}
}
