package Base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Login {
	WebDriver dr;
    PassInfo pi;
	public Login(WebDriver dr){
			this.dr=dr;
		
		}
public void createlogin(By Login,By Username, By Pass,By LoginClick, String email,String pass) {
	pi=new PassInfo(dr);
    dr.findElement(Login).click();
	
	  //wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Log in']")));
     pi.sendInfo(Username, email);
     pi.sendInfo(Pass, pass);
     dr.findElement(LoginClick).click();
}
}
