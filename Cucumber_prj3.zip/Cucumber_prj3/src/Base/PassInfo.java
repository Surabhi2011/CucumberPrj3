package Base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PassInfo {
WebDriver dr;

 PassInfo(WebDriver dr){
		this.dr=dr;
	
	}
public void sendInfo(By key,String s) {
  dr.findElement(key).sendKeys(s);;

}
}