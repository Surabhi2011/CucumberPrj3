package STEP_DEF_PKG;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Project{
	WebDriver dr;
	WebDriverWait wt;
	Base b=new Base(dr,wt);
	String []value;
	CreateLog l=new CreateLog();
	
	@Given("^Browser islaunched & DemoWebShop homepage is displayed$")
	public void browser_islaunched_DemoWebShop_homepage_is_displayed() throws Throwable {
		b.launch();
		}
	@When("^Perform login valid$")
	public void perform_login_valid() throws Throwable {
        b.validlogin();
	}
	@When("^Perform login invalid$")
	public void perform_login_invalid() throws Throwable {
	  b.invalidlogin();
	
	}	
	@Then("^Verify Successful login$")
	public void verify_Successful_login() throws Throwable {
	    value=b.success();
        l.log("Verify Successful login", value[0], value[1]);
	    
	}
	@Then("^Verify Unsuccessful login$")
	public void verify_Unsuccessful_login() throws Throwable {
		value=b.fail();
	    l.log("Verify Unsuccessful login",value[0], value[1]);
	   
	}
}