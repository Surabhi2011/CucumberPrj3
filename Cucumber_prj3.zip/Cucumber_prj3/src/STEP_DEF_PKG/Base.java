package STEP_DEF_PKG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Base.*;

public class Base {
	WebDriver dr;	
	WebDriverWait wt;
	Launch l;
	Login loginvalue;
	
	
	By TopLogin=By.xpath("//*[@href='/login']");
	By UserName=By.xpath("//input[@id='Email']");
		By Pass=By.xpath("//input[@id='Password']");
	
	By LoginClick=By.xpath("//input[@value='Log in']");
	String value[]=new String[2];
	public Base(WebDriver dr,WebDriverWait wt) {
		this.dr=dr;
		this.wt=wt;
		//PageFactory.initElements(dr, this);
	}
	public void launch() {
		 
		 System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	     dr = new ChromeDriver();
		 dr.get("http://demowebshop.tricentis.com/");
	}
	public void validlogin() {
		 // wt = new WebDriverWait(dr, 10);
		loginvalue=new Login(dr);
		loginvalue.createlogin(TopLogin, UserName, Pass, LoginClick, "surabhi12@gmail.com", "qwertyu");
		
	}
	public void invalidlogin() {
		//  wt = new WebDriverWait(dr, 10);
		loginvalue=new Login(dr);
		loginvalue.createlogin(TopLogin, UserName, Pass, LoginClick, "surabhi@gmail.com", "qwertyu");
	}
	public String[] success() {
		  value[0]="surabhi12@gmail.com";
		  value[1]=dr.findElement(By.xpath("//a[@href='/customer/info']")).getText();
		  Assert.assertEquals(value[0], value[1]);
		  System.out.println("Successful login case : Pass");
		  return value;
	}
	
	public String[] fail(){
		
		value[0]="Login was unsuccessful. Please correct the errors and try again.\n" + 
		   		"The credentials provided are incorrect";
		System.out.println(value[0]);
		value[1]=dr.findElement(By.xpath("//*[@class='validation-summary-errors']")).getText();
		System.out.println(value[1]);
		   Assert.assertEquals(value[0], value[1]);
		   System.out.println("Unsuccessful login case : Pass");
		   return value;
	}
}

